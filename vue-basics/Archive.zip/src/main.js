import { createApp } from 'vue'
import App from './App.vue'
import AppAddFriend from './components/AppAddFriend.vue';


let app=createApp(App)
app.component('add-friend',AppAddFriend)
app.mount('#app')
 