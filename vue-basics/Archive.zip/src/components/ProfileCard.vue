<template>
<div>
   <header>
        <slot name="header">Fallback Content</slot>
    </header> 
    <h1>{{ name }} {{isfav ? "*":''}}</h1>
    <p>{{email}}</p>
    <p>{{phone}}</p>
    <slot></slot>
</div>
</template>

<script>
export default {
    props:{
            name:{
                type:String,
                required:true,
                validator:function(val){
                    if(val) return true
                    else{
                        console.warn("Name should not be empty")
                        this.errors='Name Should not be empty.'
                        return false;
                    }
                }
            },
            email:{
                type:String,
                required:true
            },
            phone:{
                type:Number,
                required:true
            },
            isfav:{
                type:Boolean,
                required:false,
                default:false
            }
        },
    
}
</script>

<style scoped>
    div{
        background-color: steelblue;
        color:white;
        box-shadow: 2px 2px 2px rbga(0,0,0,0.7);
        border-radius: 5px;
        width:250px;
        margin:10px;
    }
    
</style>