<template>
<section>
    <slot></slot>
</section>
    
</template>
<script>
export default{}
</script>
<style scoped>
section{
    border:1px dotted salmon;
    margin:5px;
    display: flex;
    justify-content: center;
    align-items:center;
    padding:5px;
}
</style>