<template>
  <form @submit.prevent="onSubmit">
    <label for="name"
      >Name
      <input
        type="text"
        id="name"
        placeholder="Enter Name"
        v-model="inputData.name"
    /></label>
    <br />
    <label for="email"
      >Email
      <input
        type="email"
        id="email"
        placeholder="Enter E-Mail"
        v-model="inputData.email"
    /></label>
    <br />
    <label for="phone"
      >Phone
      <input
        type="number"
        id="phone"
        placeholder="Enter Phone Number"
        v-model="inputData.phone"
    /></label>
    <br />
    <label for="fav"
      >Favourite <input type="checkbox" id="fav" v-model="inputData.isfav"
    /></label>
    <br />
    <input type="submit" value="Add Friend" />
  </form>
</template>


<script>

export default {
  emits: ["add-friend"],
  data() {
    return {
      inputData: {
        name: "",
        email: "",
        phone: null,
        isfav: false,
      },
    };
  },
  
  methods: {
    onSubmit() {
        // using a duplicate obj
        // sending the original data and modifying will make changes to the original data
        // (pass by reference)
      this.$emit("add-friend", JSON.parse(JSON.stringify(this.inputData)));

      this.inputData.name = "";
      this.inputData.email=""
      this.inputData.phone=null;
      this.inputData.isfav=false
    },
  },

// In Options API, we need to use lifecycle methods as follows
//   mounted(){
//     alert('Mounted.')
//   }
};

</script>


<style scoped>
input[type=submit]{
    background:salmon ;
    padding: 5px;
    color:white;
}
</style>