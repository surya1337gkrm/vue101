<template>
<teleport to='body' >
  <error-component v-if="errors">
    <small>Encounted an Error!</small>
  </error-component>
</teleport>
  <h1>Hey There</h1>
  <add-friend @add-friend="addFriendEvent"></add-friend>
  <section>
    <profile-card v-for="(friend,idx) in friends" 
    :key="friend.name"
    v-bind='friend'>
    <!-- named slot -->
    <!-- either use # to specify the slot name or use v-slot -->
    <template #header>
       <p class="friend">Friend {{idx+1}}</p>
    </template>
     <button @click="deleteFriend(friend.id)">Delete</button>
    </profile-card>
  </section>
  
</template>

<script>
// local components
// either pass each property as seperate prop [ :name="friend.name"] 
// or pass the entire object using v-bind="friend"
import ProfileCard from './components/ProfileCard.vue'
import ErrorComponent from './components/ErrorComponent.vue'
export default {
  data(){
    return {
      errors:false,
     friends:[
      {
        id:1,
        name:'Surya',
        phone:9372251478,
        email:'suryavenkatesh0@gmail.com',
      },
      {
        id:2,
        name:'Venkatesh',
        phone:9372251479,
        email:'maddy@gmail.com',
        isfav:true
      },
      {
        id:3,
        name:'Vijjana',
        phone:9372251480,
        email:'madhuri0@gmail.com',
        isfav:true
      }
     ]
    }
    
  },
  components:{
      'profile-card':ProfileCard,
      'error-component':ErrorComponent
  },
  methods:{
    addFriendEvent(data){
      if(data.name && data.email && data.phone){
        this.friends.unshift({id:this.friends.length+1,...data})
      }else{
        this.errors=true;
        setTimeout(()=>{
          this.errors=false
        },1000)
      }
      
    },
    deleteFriend(id){
      this.friends=this.friends.filter(friend=>friend.id!==id);
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
label{
  margin-right: 5px;
}
form{
  background-color: steelblue;
  color:white;
  padding:15px;
  margin:5px;
  border-radius: 5px;
  box-shadow: 2px 2px 2px rgba(0,0,0,0.7);
}

input:focus{
  outline: none;
}
input{
  margin:5px;
}

section{
  display:flex;
  flex-wrap: wrap;
  margin:10px;
}
button{
  background-color: salmon;
  color:white;
  padding:5px;
  margin:5px;
}
.friend {
  background-color: green;
  width:fit-content;
  padding: 0px 5px;
  border:1px solid white;
  box-shadow: 2px rgba(0,0,0,0.7);
  border-radius: 0 5px 5px 0;
}
</style>
